/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package utils;

/**
 *
 * @author laura
 */
public interface Semana {

    /**
     *
     */
    String MONDAY = "L";

    /**
     *
     */
    String TUESDAY = "M";

    /**
     *
     */
    String WEDNESDAY = "X";

    /**
     *
     */
    String THURSDAY = "J";

    /**
     *
     */
    String FRIDAY = "V";

    /**
     *
     */
    String SATURDAY = "S";

    /**
     *
     */
    String SUNDAY = "D";
}
